/*
 * File: SeaPort.java
 * Author: Adam Ohsie
 * Date: October 14, 2018
 * Purpose: The purpose of this class is to hold
 * the arraylists for the docks, que, ships, and persons.
 */

import javax.swing.*;
import java.util.*;

public class SeaPort extends Thing {
    // Arraylists to store docks, ships, ships
    // waiting to dock, and people
    private ArrayList<Dock> docks = new ArrayList<>();
    private ArrayList<Ship> que = new ArrayList<>();
    private ArrayList<Ship> ships = new ArrayList<>();
    private ArrayList<Person> persons = new ArrayList<>();
    // stack for the docks
    private final Stack<Dock> dockStack = new Stack<>();
    // hashmap of resource pools of people
    private final HashMap<String, ArrayList<Person>>
            personSkillArrayListHashMap = new HashMap<>();
    // hashmap to hold the counter of how many people in the pool
    private HashMap<String, Integer>
            skillCounterHashMap = new HashMap<>();
    // arraylist of skills
    private ArrayList<String>
            skillArrayList = new ArrayList<>();
    // hashmap of labels
    private HashMap<String, JLabel>
            labelHashMap = new HashMap<>();

    public SeaPort(Scanner scanner) {
        super(scanner);
    }

    public ArrayList<Dock> getDocks() { return docks; }

    public ArrayList<Ship> getQue() {
        return que;
    }

    public ArrayList<Ship> getShips() {
        return ships;
    }

    public ArrayList<Person> getPersons() {
        return persons;
    }

    public Stack<Dock> getDockStack() { return dockStack; }

    public HashMap<String, ArrayList<Person>> getPersonSkillArrayListHashMap() {
        return personSkillArrayListHashMap;
    }

    public HashMap<String, Integer> getSkillCounterHashMap() {
        return skillCounterHashMap;
    }

    public ArrayList<String> getSkillArrayList() {
        return skillArrayList;
    }

    public HashMap<String, JLabel> getLabelHashMap() {
        return labelHashMap;
    }

    @Override
    public String toString() {
        String string = "\n\nSeaPort: " + super.toString();
        for (Dock dock: docks) string += "\n > " + dock;
        if (docks.isEmpty()) string += "none";
        string += "\n\n --- List of all ships in que: ";
        for (Ship ship: que) string += "\n > " + ship;
        if (que.isEmpty()) string += "none";
        string += "\n\n --- List of all ships: ";
        for (Ship ship: ships) string += "\n > " + ship;
        if (ships.isEmpty()) string += "none";
        string += "\n\n --- List of all persons: ";
        for (Person person: persons) string += "\n > " + person;
        if (persons.isEmpty()) string += "none";
        string += "\n\n --- List of all jobs: \n";
        for (Ship ship: ships)
            for (Job job: ship.getJobs()) string += " > " + job;
        return string;
    }
}
