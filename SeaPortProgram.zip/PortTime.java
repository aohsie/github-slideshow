/*
 * File: PortTime.java
 * Author: Adam Ohsie
 * Date: September 15, 2018
 * Purpose: The purpose of this class is to
 * set the time of each port
 */

public class PortTime {
    int time;
}
