/*
 * File: Job.java
 * Author: Adam Ohsie
 * Date: October 14, 2018
 * Purpose: The purpose of this class is
 * to provide jobs for the ships
 */

import javax.swing.*;
import java.util.*;

public class Job extends Thing implements Runnable {
    private ArrayList<String> requirements = new ArrayList<>();
    private HashMap<String, Stack<Person>> personSkillHashMap = new HashMap<>();
    private double duration;
    private World world = SeaPortProgram.world;
    private final Ship ship = world.getShipByIndex(this.getParent());
    private boolean jobFinished = false, jobIsWaiting = false,
            jobIsReady = false, jobIsCancelled = false, insufficientPersons = false;
    private Status status;
    private JProgressBar progressBar = new JProgressBar();
    private JLabel progressBarLabel = new JLabel("Waiting...");
    private JLabel personAcquiredLabel = new JLabel();
    private JLabel personsRequiredLabel = new JLabel();
    private int time;

    private enum Status {WAITING, RUNNING, CANCELLED, DONE}

    public Job(Scanner scanner) {
        super(scanner);
        if (scanner.hasNextDouble()) duration = scanner.nextDouble();
        while (scanner.hasNext()) {
            if (scanner.hasNext("job")) {
                scanner.nextLine();
                break;
            } else requirements.add(scanner.next());
        }
        // sets the labels for the skills required
        String string = "";
        if (!requirements.isEmpty()) {
            for (String skill : requirements)
                string += skill + " ";
        } else string += "None Required";
        personsRequiredLabel.setText(string);
    }

    @Override
    public void run() {
        SeaPort port;
        // sets the parent port and, if applicable, parent dock
        if (world.getPortIndexHashMap().containsKey(ship.getParent()))
            port = world.getPortIndexHashMap().get(ship.getParent());
        else {
            ship.setDock(world.getDockIndexHashMap().get(ship.getParent()));
            port = world.getPortIndexHashMap().get(ship.getDock().getParent());
        }

        // synchronized statement for the ship
        synchronized (ship) {
            // tells everyone that the thread started
            jobIsWaiting = true;

            // loops through the jobs to make sure all
            // the threads started before docking the ship
            for (Job job : ship.getJobs()) {
                if (!job.jobIsWaiting) {
                    while (!ship.isShipReady()) {
                        try {
                            // the ship waits until there
                            // is an available dock
                            ship.wait();
                        } catch (InterruptedException e) {
                        }
                    }
                    // this breaks the loop
                    // and allow the ship to dock
                    break;
                }
            }
            // the last job to start should wait
            // for an open dock and dock the ship
            if (!ship.isShipReady()) {
                synchronized (port.getDockStack()) {
                    while (port.getDockStack().isEmpty()) {
                        putThreadToSleep(200);
                        updateStatus(Status.WAITING);
                        try {
                            port.getDockStack().wait();
                        } catch (InterruptedException e) {
                        }
                    }
                    // pops the stack and docks the ship
                    ship.setDock(port.getDockStack().pop());
                    ship.dockShip(ship);
                    ship.setShipIsReady(true);
                    ship.notifyAll();
                }
            }
        }

        // sorts the list of skills to avoid deadlocks
        Collections.sort(requirements);

        // creates a copy of the arraylist of skills, so it can
        // be updated depending on how may skills still require people
        ArrayList<String> remainingRequirements = new ArrayList<>();
        remainingRequirements.addAll(requirements);

        ArrayList<Person> personsAcquiredList = new ArrayList<>();

        boolean startJobOver;
        long startTime, endTime;
        Stack<Person> skillStack;
        while (!jobIsReady && !jobIsCancelled) {
            startJobOver = false;
            // if there are no skills the job should continue and run
            if (requirements.size() == 0) {
                break;
            } else updatePersonsRequired(remainingRequirements);
            for (String skill : requirements) {
                // a stack is created for each requirement, to be able
                // to hold multiple people with the same skill
                if (!personSkillHashMap.containsKey(skill)) {
                    skillStack = new Stack<>();
                    personSkillHashMap.put(skill, skillStack);
                }
                // if there is no one with this skill at the port, or there are not enough
                // people with this skill for this job, the job should cancel
                if (!port.getPersonSkillArrayListHashMap().containsKey(skill) ||
                        port.getSkillCounterHashMap().get(skill) == personSkillHashMap.get(skill).size()) {
                    insufficientPersons = true;
                    jobIsCancelled = true;
                    updateStatus(Status.CANCELLED);
                    SwingUtilities.invokeLater(() ->
                        personsRequiredLabel.setText("Did Not Have A " + skill));
                    putThreadToSleep(100);
                    break;
                } else {
                        synchronized (port.getPersonSkillArrayListHashMap().get(skill)) {
                            while (port.getPersonSkillArrayListHashMap().get(skill).isEmpty()) {
                                putThreadToSleep(200);
                                try {
                                    // this times the wait period for the skill. If it's too long
                                    // the job should releas the people it's already holding, and wait again
                                    startTime = System.currentTimeMillis();
                                    port.getPersonSkillArrayListHashMap().get(skill).wait(100);
                                    endTime = System.currentTimeMillis();
                                    if (endTime - startTime >= 100) {
                                        for (String checkSkill : requirements) {
                                            putThreadToSleep(100);
                                            if (personSkillHashMap.containsKey(checkSkill)
                                                    && !personSkillHashMap.get(checkSkill).isEmpty()) {
                                                port.getPersonSkillArrayListHashMap().get
                                                        (checkSkill).add(personSkillHashMap.get(checkSkill).pop());
                                                personsAcquiredList.remove(0);
                                                updatePersonsAcquired(personsAcquiredList);
                                                remainingRequirements.add(checkSkill);
                                                Collections.sort(remainingRequirements);
                                                updatePersonsRequired(remainingRequirements);
                                                updateResourcePools
                                                        (checkSkill, port, port.getPersonSkillArrayListHashMap().get(checkSkill));
                                            }
                                        }
                                        startJobOver = true;
                                        break;
                                    }
                                } catch (InterruptedException e) {
                                }
                            }
                            if (startJobOver) {
                                jobIsReady = false;
                                break;
                            } else jobIsReady = true;
                            Person person = port.getPersonSkillArrayListHashMap().get(skill).get(0);
                            personSkillHashMap.get(skill).push(person);
                            personsAcquiredList.add(person);
                            updatePersonsAcquired(personsAcquiredList);
                            port.getPersonSkillArrayListHashMap().get(skill).remove(0);
                            remainingRequirements.remove(0);
                            updatePersonsRequired(remainingRequirements);
                            updateResourcePools(skill, port, port.getPersonSkillArrayListHashMap().get(skill));
                            putThreadToSleep(200);
                        }
                }
            }
        }

        if (!insufficientPersons) {
            time = 0;
            while (time < duration) {
                putThreadToSleep(300);
                updateStatus(Status.RUNNING);
                time += 5;
            }
            putThreadToSleep(100);
            updateStatus(Status.DONE);
        }

        for (String skill : requirements) {
            if (personSkillHashMap.containsKey(skill) && !personSkillHashMap.get(skill).isEmpty()) {
                synchronized (port.getPersonSkillArrayListHashMap().get(skill)) {
                    port.getPersonSkillArrayListHashMap().get(skill).add(personSkillHashMap.get(skill).pop());
                    updateResourcePools(skill, port, port.getPersonSkillArrayListHashMap().get(skill));
                    port.getPersonSkillArrayListHashMap().get(skill).notifyAll();
                }
            }
        }


        // tells the ship to leave the
        // dock when the last job is finished
        synchronized (ship) {
            int count = 0;
            jobFinished = true;
            for (Job job : ship.getJobs()) {
                if (!job.jobFinished) break;
                else count++;
            }
            if (count == ship.getJobs().size()) {
                synchronized (port.getDockStack()) {
                    ship.getDock().leaveDock();
                    port.getDockStack().push(ship.getDock());
                    port.getDockStack().notify();
                }
            }
        }
    }


    // method that starts the thread
    public void startThread() {
        new Thread(this, this.getName()).start();
    }

    // method that makes thread putThreadToSleep
    // for x amount of time
    public void putThreadToSleep(int x) {
        try {
            Thread.sleep(x);
        } catch (InterruptedException e) {
        }
    }

    // method that updates the status of the
    // job and the progress progressBar
    public void updateStatus(Status st) {
        status = st;
        SwingUtilities.invokeLater(() -> {
            switch (status) {
                case WAITING:
                    progressBar.setValue(0);
                    progressBarLabel.setText("Waiting...");
                    break;
                case RUNNING:
                    progressBar.setValue(time);
                    progressBarLabel.setText("Running...");
                    break;
                case CANCELLED:
                    progressBar.setValue(0);
                    progressBarLabel.setText("Cancelled.");
                    personAcquiredLabel.setText("None Required");
                    break;
                case DONE:
                    progressBar.setValue(100);
                    progressBarLabel.setText("Finished.");
                    personAcquiredLabel.setText("No More Required");
                    break;
            }
        });
    }

    // method that updates the resource pools on the GUI
    public void updateResourcePools(String skill, SeaPort port, ArrayList<Person> list) {
        String string = "(" + port.getName() + ") " + skill + ":      ";
        if (list.isEmpty()) string += "No People Available";
        else {
            for (Person person : list) {
                string += person.getName() + " ";
            }
        }
        String finalString = string;
        SwingUtilities.invokeLater(() ->
            port.getLabelHashMap().get(skill).setText(finalString));
    }

    // method that updates the people acquired on the GUI
    public void updatePersonsAcquired(ArrayList<Person> list) {
        String string = "";
        if (!list.isEmpty()) {
            for (Person person : list) {
                string += person.getName() + " ";
            }
        } else string += "None Acquired";
        String finalString = string;
        SwingUtilities.invokeLater(() ->
            personAcquiredLabel.setText(finalString));
    }

    // method that updates the skills still required on the GUI
    public void updatePersonsRequired(ArrayList<String> list) {
        String string = "";
        if (!list.isEmpty()) {
            for (String skill : list) {
                string += skill + " ";
            }
        } else string += "No More Required";
        String finalString = string;
        SwingUtilities.invokeLater(() ->
            personsRequiredLabel.setText(finalString));
    }

    public ArrayList<String> getRequirements() {
        return requirements;
    }

    public JProgressBar getProgressBar() {
        return progressBar;
    }

    public JLabel getProgressBarLabel() {
        return progressBarLabel;
    }

    public JLabel getPersonAcquiredLabel() { return personAcquiredLabel; }

    public JLabel getPersonsRequiredLabel() { return personsRequiredLabel; }

    @Override
    public String toString() {
        String string = super.toString();
        for (String skill : requirements)
            string += " " + skill;
        return string + "\n";
    }
}
