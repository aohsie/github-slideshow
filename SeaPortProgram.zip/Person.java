/*
 * File: Person.java
 * Author: Adam Ohsie
 * Date: October 14, 2018
 * Purpose: The purpose of this class is
 * to set the skill for each person
 */

import java.util.*;

public class Person extends Thing {
    String skill;

    // scans for skills
    public Person(Scanner scanner) {
        super(scanner);
        if (scanner.hasNext()) skill = scanner.next();
    }

    public String getSkill() {
        return skill;
    }

    @Override
    public String toString() {
        return "Person: " + super.toString() + " " + skill;
    }
}
