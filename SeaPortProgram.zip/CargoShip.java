/*
 * File: CargoShip.java
 * Author: Adam Ohsie
 * Date: October 14, 2018
 * Purpose: The purpose of this class is to create a
 * cargo ship and set the cargo value, weight and volume
 */

import java.util.*;

public class CargoShip extends Ship {
    private double cargoValue;
    private double cargoVolume;
    private double cargoWeight;

    // scans for cargo value, volume, and weight
    public CargoShip(Scanner scanner) {
        super(scanner);
        if (scanner.hasNextDouble()) cargoValue = scanner.nextDouble();
        if (scanner.hasNextDouble()) cargoVolume = scanner.nextDouble();
        if (scanner.hasNextDouble()) cargoWeight = scanner.nextDouble();
    }

    @Override
    public String toString() {
        return "Cargo ship: " + super.toString();
    }
}
