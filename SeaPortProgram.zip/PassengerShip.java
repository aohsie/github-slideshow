/*
 * File: PassengerShip.java
 * Author: Adam Ohsie
 * Date: October 14, 2018
 * Purpose: The purpose of this class is to create a
 * passenger ship and set the number of rooms,
 * occupied rooms, and passengers
 */

import java.util.*;

public class PassengerShip extends Ship {
    private int numberOfOccupiedRooms;
    private int numberOfPassengers;
    private int numberOfRooms;

    // scans for rooms and passengers
    public PassengerShip(Scanner scanner) {
        super(scanner);
        if (scanner.hasNextInt()) numberOfOccupiedRooms = scanner.nextInt();
        if (scanner.hasNextInt()) numberOfPassengers = scanner.nextInt();
        if (scanner.hasNextInt()) numberOfRooms = scanner.nextInt();
    }

    @Override
    public String toString() {

        return "Passenger ship: " + super.toString();
    }
}
