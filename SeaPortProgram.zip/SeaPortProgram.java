/*
 * File: SeaPortProgram.java
 * Author: Adam Ohsie
 * Date: October 14, 2018
 * Purpose: The purpose of this class is
 * to provide the Gui to run the program
 */

import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;
import java.awt.*;
import java.io.*;
import java.util.*;

public class SeaPortProgram extends JFrame {
    // creates world object
    public static World world = new World();

    // constructor that creates the GUI
    public SeaPortProgram() {
        super("Seaport Program");
        setSize(1350, 720);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setLayout(new GridLayout(4, 0));
        setBackground(Color.lightGray);

        DefaultMutableTreeNode worldRoot = new DefaultMutableTreeNode("World");
        JTree jTree = new JTree(worldRoot);
        JScrollPane jTreePane = new JScrollPane(jTree);
        jTreePane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        //add(jTreePane);

        // creating the top panel for parsing the file
        JPanel createGuiPanel = new JPanel(new GridLayout(0, 2, 50, 0));
        JPanel leftPanel = new JPanel(new GridLayout(3, 3, 50, 50));
        JPanel rightPanel = new JPanel(new GridLayout(1, 0));

        JTextPane textPane = new JTextPane();
        textPane.setEditable(false);

        JScrollPane scrollPane = new JScrollPane(textPane);
        scrollPane.setBackground(Color.white);
        scrollPane.setLayout(new ScrollPaneLayout());
        scrollPane.setVerticalScrollBarPolicy
                (ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setHorizontalScrollBarPolicy
                (ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);

        JButton createSeaPortButton = new JButton("Create");
        JLabel createSeaportsLabel = new JLabel("Create Seaports");

        leftPanel.add(createSeaportsLabel);
        leftPanel.add(createSeaPortButton);
        rightPanel.add(jTreePane);

        createGuiPanel.add(leftPanel, BorderLayout.WEST);
        createGuiPanel.add(rightPanel, BorderLayout.EAST);
        add(createGuiPanel);

        JFileChooser jfc = new JFileChooser(".");
        int retVal = jfc.showOpenDialog(this);

        // button to parse the file
        createSeaPortButton.addActionListener(e -> {
            try {
                // creates the file chooser and parses the file
                if (retVal == jfc.APPROVE_OPTION) {
                    Scanner scanner = new Scanner(jfc.getSelectedFile());
                    world.process(scanner);
                    DefaultMutableTreeNode allPortsNode = new DefaultMutableTreeNode("Ports");
                    for (SeaPort port : world.getPorts()) {
                        worldRoot.add(allPortsNode);
                        DefaultMutableTreeNode portNode = new DefaultMutableTreeNode(port.getName());
                        allPortsNode.add(portNode);
                        DefaultMutableTreeNode allDocksNode = new DefaultMutableTreeNode("Docks");
                        portNode.add(allDocksNode);
                        for (Dock dock : port.getDocks()) {
                            DefaultMutableTreeNode dockNode = new DefaultMutableTreeNode(dock.getName());
                            allDocksNode.add(dockNode);
                            if (dock.getShip() != null) {
                                DefaultMutableTreeNode shipNode = new DefaultMutableTreeNode(dock.getShip().getName());
                                dockNode.add(shipNode);
                                for (Job job : dock.getShip().getJobs()) {
                                    DefaultMutableTreeNode jobNode = new DefaultMutableTreeNode(job.getName());
                                    shipNode.add(jobNode);
                                    for (String skill : job.getRequirements()) {
                                        DefaultMutableTreeNode skillNode = new DefaultMutableTreeNode(skill);
                                        jobNode.add(skillNode);
                                    }
                                }
                            }
                        }
                        DefaultMutableTreeNode shipsInQueNode = new DefaultMutableTreeNode("Que");
                        portNode.add(shipsInQueNode);
                        for (Ship ship : port.getQue()) {
                            DefaultMutableTreeNode shipRoot = new DefaultMutableTreeNode(ship.getName());
                            shipsInQueNode.add(shipRoot);
                            for (Job job : ship.getJobs()) {
                                DefaultMutableTreeNode jobNode = new DefaultMutableTreeNode(job.getName());
                                shipRoot.add(jobNode);
                                for (String skill : job.getRequirements()) {
                                    DefaultMutableTreeNode skillNode = new DefaultMutableTreeNode(skill);
                                    jobNode.add(skillNode);
                                }
                            }
                        }
                        DefaultMutableTreeNode allShipsNode = new DefaultMutableTreeNode("Ships");
                        portNode.add(allShipsNode);
                        for (Ship ship : port.getShips()) {
                            DefaultMutableTreeNode shipRoot = new DefaultMutableTreeNode(ship.getName());
                            allShipsNode.add(shipRoot);
                            for (Job job : ship.getJobs()) {
                                DefaultMutableTreeNode jobNode = new DefaultMutableTreeNode(job.getName());
                                shipRoot.add(jobNode);
                                for (String skill : job.getRequirements()) {
                                    DefaultMutableTreeNode skillNode = new DefaultMutableTreeNode(skill);
                                    jobNode.add(skillNode);
                                }
                            }
                        }
                        DefaultMutableTreeNode allPersonsNode = new DefaultMutableTreeNode("People");
                        portNode.add(allPersonsNode);
                        for (Person person : port.getPersons()) {
                            DefaultMutableTreeNode personNode = new DefaultMutableTreeNode(person.getName());
                            DefaultMutableTreeNode personSkillNode = new DefaultMutableTreeNode(person.getSkill());
                            personNode.add(personSkillNode);
                            allPersonsNode.add(personNode);
                        }
                    }
                }
            } catch (FileNotFoundException ex) {
                System.out.println("File not found");
            }
        });


        // Creating the center panel for sorting
        JPanel sortPanel = new JPanel(new GridLayout(3, 0, 0, 10));
        JPanel topPanel = new JPanel(new GridLayout(1, 7, 20, 0));
        JPanel middlePanel = new JPanel(new GridLayout(1, 5, 50, 0));
        JPanel bottomPanel = new JPanel(new GridLayout(1, 3, 100, 0));

        JTextPane sortTextPane = new JTextPane();
        sortTextPane.setEditable(false);

        JScrollPane sortScrollPane =
                new JScrollPane(sortTextPane);
        sortScrollPane.setBackground(Color.white);
        sortScrollPane.setLayout(new ScrollPaneLayout());
        sortScrollPane.setVerticalScrollBarPolicy
                (ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        JRadioButton seaPortsJRB = new JRadioButton("Seaports");
        JRadioButton docksJRB = new JRadioButton("Docks");
        JRadioButton shipsInQueJRB = new JRadioButton("Ships In Que");
        JRadioButton allShipsJRB = new JRadioButton("All Ships");
        JRadioButton personsJRB = new JRadioButton("Persons");
        JRadioButton jobsJRB = new JRadioButton("Jobs");

        ButtonGroup sortArrayBG = new ButtonGroup();
        sortArrayBG.add(seaPortsJRB);
        sortArrayBG.add(docksJRB);
        sortArrayBG.add(shipsInQueJRB);
        sortArrayBG.add(allShipsJRB);
        sortArrayBG.add(personsJRB);
        sortArrayBG.add(jobsJRB);

        JRadioButton draftJRB = new JRadioButton("Draft");
        JRadioButton lengthJRB = new JRadioButton("Length");
        JRadioButton weightJRB = new JRadioButton("Weight");
        JRadioButton widthJRB = new JRadioButton("Width");

        ButtonGroup sortQueBG = new ButtonGroup();
        sortQueBG.add(draftJRB);
        sortQueBG.add(lengthJRB);
        sortQueBG.add(weightJRB);
        sortQueBG.add(widthJRB);

        JLabel sortByNameLabel = new JLabel("Sort Chosen ArrayList By Name");
        JLabel sortShipsInQueLabel = new JLabel("Sort Ships In Que By:");

        topPanel.add(sortByNameLabel);
        topPanel.add(seaPortsJRB);
        topPanel.add(docksJRB);
        topPanel.add(shipsInQueJRB);
        topPanel.add(allShipsJRB);
        topPanel.add(personsJRB);
        topPanel.add(jobsJRB);

        middlePanel.add(sortShipsInQueLabel);
        middlePanel.add(draftJRB);
        middlePanel.add(lengthJRB);
        middlePanel.add(weightJRB);
        middlePanel.add(widthJRB);

        JButton sortByNameButton = new JButton("Sort By Name");
        JButton sortShipsInQueButton = new JButton("Sort Que:");
        bottomPanel.add(sortByNameButton);
        bottomPanel.add(sortShipsInQueButton);
        bottomPanel.add(sortScrollPane);

        sortPanel.add(topPanel, BorderLayout.NORTH);
        sortPanel.add(middlePanel, BorderLayout.CENTER);
        sortPanel.add(bottomPanel, BorderLayout.SOUTH);
        add(sortPanel);

        // allow the user to sort the arraylist by name
        sortByNameButton.addActionListener(e1 -> {
            String result = "";
            // sorts the seaports
            if (seaPortsJRB.isSelected()) {
                world.sortSeaPorts();
                for (SeaPort port : world.getPorts()) {
                    result += "\n" + port.getName();
                }
                // sorts the docks
            } else if (docksJRB.isSelected()) {
                world.sortDocks();
                for (SeaPort port : world.getPorts()) {
                    result += "\nPort: " + port.getName() + "\n";
                    for (Dock dock : port.getDocks())
                        result += dock.getName() + "\n";
                }
                // sorts the ships in que
            } else if (shipsInQueJRB.isSelected()) {
                world.sortShipsInQue();
                for (SeaPort port : world.getPorts()) {
                    result += "\n\nPort: " + port.getName() + "\n";
                    for (Ship ship : port.getQue())
                        result += ship.getName() + " ";
                }
                //sorts all the ships
            } else if (allShipsJRB.isSelected()) {
                world.sortShips();
                for (SeaPort port : world.getPorts()) {
                    result += "\nPort: " + port.getName() + "\n";
                    for (Ship ship : port.getShips())
                        result += ship.getName() + "\n";
                }
                // sorts the people
            } else if (personsJRB.isSelected()) {
                world.sortPeople();
                for (SeaPort port : world.getPorts()) {
                    result += "\nPort: " + port.getName() + "\n";
                    for (Person person : port.getPersons())
                        result += person.getName() + "\n";
                }
            } else if (jobsJRB.isSelected()) {
                world.sortJobs();
                for (SeaPort port : world.getPorts())
                    for (Ship ship : port.getShips()) {
                        result += "\nShip: " + ship.getName() + "\n";
                        if (!ship.getJobs().isEmpty()) {
                            for (Job job : ship.getJobs())
                                result += job.getName() + "\n";
                        } else result += "no jobs\n";
                    }
            }
            sortTextPane.setText(result);
        });

        // sorts the ships in que
        sortShipsInQueButton.addActionListener(e1 -> {
            String result = "";
            // sorts by draft
            if (draftJRB.isSelected()) {
                world.sortQueByDraft();
                for (SeaPort port : world.getPorts()) {
                    result += "\nPort: " + port.getName() + "\n";
                    for (Ship ship : port.getQue())
                        result += ship.getName() + " " + String.valueOf(ship.getDraft()) + "\n";
                    sortTextPane.setText(result);
                }
                // sorts by length
            } else if (lengthJRB.isSelected()) {
                world.sortQueByLength();
                for (SeaPort port : world.getPorts()) {
                    result += "\nPort: " + port.getName() + "\n";
                    for (Ship ship : port.getQue())
                        result += ship.getName() + " " + String.valueOf(ship.getLength()) + "\n";
                    sortTextPane.setText(result);
                }
                // sorts by weight
            } else if (weightJRB.isSelected()) {
                world.sortQueByWeight();
                for (SeaPort port : world.getPorts()) {
                    result += "\nPort: " + port.getName() + "\n";
                    for (Ship ship : port.getQue())
                        result += ship.getName() + " " + String.valueOf(ship.getWeight()) + "\n";
                    sortTextPane.setText(result);
                }
                // sorts by width
            } else if (widthJRB.isSelected()) {
                world.sortQueByWidth();
                for (SeaPort port : world.getPorts()) {
                    result += "\nPort: " + port.getName() + "\n";
                    for (Ship ship : port.getQue())
                        result += "\n" + ship.getName() + " " + String.valueOf(ship.getWidth());
                    sortTextPane.setText(result);
                }
            }
        });


        // creating the bottom panel for searching
        JPanel searchPanel = new JPanel(new GridLayout(4, 0));
        JPanel buttonPanel = new JPanel(new GridLayout(1, 4, 5, 0));
        JPanel buttonLabelPanel = new JPanel(new GridLayout(1, 2, 50, 0));
        JPanel searchFieldsPanel = new JPanel(new GridLayout(1, 6, 5, 0));
        JPanel searchLabelPanel = new JPanel(new GridLayout(1, 4, 20, 0));

        JTextPane searchTextPane = new JTextPane();
        searchTextPane.setEditable(false);

        JScrollPane searchScrollPane =
                new JScrollPane(searchTextPane);
        searchScrollPane.setBackground(Color.white);
        searchScrollPane.setLayout(new ScrollPaneLayout());
        searchScrollPane.setVerticalScrollBarPolicy
                (ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        searchScrollPane.setHorizontalScrollBarPolicy
                (ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);

        JRadioButton nameJRB = new JRadioButton("Name");
        JRadioButton indexJRB = new JRadioButton("Index");
        JRadioButton skillJRB = new JRadioButton("Skill");

        ButtonGroup bg = new ButtonGroup();
        bg.add(nameJRB);
        bg.add(indexJRB);
        bg.add(skillJRB);

        JLabel userSpecifiedSearchLabel = new JLabel("User Specified Search");
        JLabel chooseNameIndexSkillLabel = new JLabel("Choose Name, Index, or Skill");
        JLabel inputFieldLabel = new JLabel("Input Search");
        JLabel resultFieldLabel = new JLabel("Result of Search");

        buttonLabelPanel.add(userSpecifiedSearchLabel);
        buttonLabelPanel.add(chooseNameIndexSkillLabel);
        searchLabelPanel.add(inputFieldLabel);
        searchLabelPanel.add(resultFieldLabel);

        JButton searchButton = new JButton("Search");

        buttonPanel.add(searchButton);
        buttonPanel.add(nameJRB);
        buttonPanel.add(indexJRB);
        buttonPanel.add(skillJRB);

        JTextField searchField = new JTextField();

        searchFieldsPanel.add(searchField);
        searchFieldsPanel.add(searchScrollPane);

        searchPanel.add(buttonLabelPanel);
        searchPanel.add(buttonPanel);
        searchPanel.add(searchLabelPanel);
        searchPanel.add(searchFieldsPanel);
        add(searchPanel);

        // allows user to search the file
        searchButton.addActionListener(e -> {
            String string = searchField.getText();
            String result = "";
            // looks up the hashmaps for the matching name
            if (nameJRB.isSelected()) {
                if (world.getPortNameHashMap().containsKey(string))
                    for (SeaPort seaPort : world.getSeaPortByName(string))
                        result += "\n" + seaPort;
                else if (world.getDockNameHashMap().containsKey(string))
                    for (Dock dock : world.getDockByName(string))
                        result += "\n" + dock;
                else if (world.getShipNameHashMap().containsKey(string))
                    for (Ship ship : world.getShipByName(string))
                        result += "\n" + ship;
                else if (world.getPersonNameHashMap().containsKey(string))
                    for (Person person : world.getPersonByName(string))
                        result += "\n" + person;
                else if (world.getJobNameHashMap().containsKey(string))
                    for (Job job : world.getJobByName(string))
                        result += "\n" + job;
                // looks up the hashmaps for the matching index
            } else if (indexJRB.isSelected()) {
                if (world.getSeaPortByIndex(Integer.parseInt(string)) != null)
                    result = world.getSeaPortByIndex(Integer.parseInt(string)).toString();
                else if (world.getDockByIndex(Integer.parseInt(string)) != null)
                    result = world.getDockByIndex(Integer.parseInt(string)).toString();
                else if (world.getShipByIndex(Integer.parseInt(string)) != null)
                    result = world.getShipByIndex(Integer.parseInt(string)).toString();
                else if (world.getPersonByIndex(Integer.parseInt(string)) != null)
                    result = world.getPersonByIndex(Integer.parseInt(string)).toString();
                else if (world.getJobByIndex(Integer.parseInt(string)) != null)
                    result = world.getJobByIndex(Integer.parseInt(string)).toString();
                // looks up the hashmaps for the matching skill
            } else if (skillJRB.isSelected()) {
                if (world.getPersonSkillHashMap().containsKey(string))
                    for (Person person : world.getPersonBySkill(string))
                        result += "\n" + person;
                result += "\n\n";
                if (world.getJobSkillHashMap().containsKey(string))
                    for (Job job : world.getJobBySkill(string))
                        result += job;
            }
            searchTextPane.setText(result);
        });


        // creating the job progress panel
        JPanel jobProgressPanel = new JPanel(new GridLayout(0, 2, 50, 0));
        JPanel jobButtonPanel = new JPanel(new GridLayout(0, 1, 0, 20));
        JPanel jobPBarPanel = new JPanel(new GridLayout(0, 5, 10, 20));
        JPanel jobSkillTrackPanel = new JPanel(new GridLayout(0, 1, 10, 15));
        JPanel resourcePoolPanel = new JPanel(new GridLayout(0, 1));

        jobPBarPanel.setBackground(Color.white);
        JScrollPane jobProgressScrollPane = new JScrollPane(jobPBarPanel);
        jobProgressScrollPane.setVerticalScrollBarPolicy
                (ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        jobSkillTrackPanel.setBackground(Color.white);
        JScrollPane skillProgressScrollPane = new JScrollPane(jobSkillTrackPanel);
        skillProgressScrollPane.setVerticalScrollBarPolicy
                (ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        JButton jobStartButton = new JButton("Start Jobs");
        jobButtonPanel.add(jobStartButton);
        jobButtonPanel.add(new JLabel("    Resource Pools"));

        resourcePoolPanel.add(jobButtonPanel);
        resourcePoolPanel.add(skillProgressScrollPane);

        jobProgressPanel.add(resourcePoolPanel);
        jobProgressPanel.add(jobProgressScrollPane);

        add(jobProgressPanel);

        // starts the thread for each job
        // and updates its progress
        jobStartButton.addActionListener(e -> {
            Ship ship;
            String string;
            JLabel label;
            // loops through the ports and creates the label
            // for each resource pool
            for (SeaPort port : world.getPorts()) {
                for (String skill : port.getSkillArrayList()) {
                    string = "(" + port.getName() + ") " + skill + ":       ";
                    for (Person person : port.getPersonSkillArrayListHashMap().get(skill)) {
                        string += person.getName() + " ";
                    }
                    label = new JLabel(string);
                    jobSkillTrackPanel.add(label);
                    // adds the labels to a hashmap
                    port.getLabelHashMap().put(skill, label);
                }
            }
            jobPBarPanel.add(new JLabel("Job"));
            jobPBarPanel.add(new JLabel("Person Acquired"));
            jobPBarPanel.add(new JLabel("Persons Required"));
            jobPBarPanel.add(new JLabel("Job Status"));
            jobPBarPanel.add(new JLabel("Progress Bar"));
            for (Job job : world.getAllJobs()) {
                ship = world.getShipByIndex(job.getParent());
                job.startThread();
                jobPBarPanel.add(new JLabel("(" + ship.getName() + ") " + job.getName()));
                jobPBarPanel.add(job.getPersonAcquiredLabel());
                jobPBarPanel.add(job.getPersonsRequiredLabel());
                jobPBarPanel.add(job.getProgressBarLabel());
                jobPBarPanel.add(job.getProgressBar());
                jobProgressPanel.revalidate();
                jobProgressPanel.repaint();
            }
        });

        setVisible(true);
    }

    public static void main(String args[]) { new SeaPortProgram(); }
}
