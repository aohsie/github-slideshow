/*
 * File: Dock.java
 * Author: Adam Ohsie
 * Date: October 14, 2018
 * Purpose: The purpose of this class is to add
 * a ship to the appropriate dock.
 */

import java.util.*;

public class Dock extends Thing {
    private Ship ship;

    public Dock(Scanner scanner) {
        super(scanner);
    }

    // assigns the ship to the dock
    public void dockShip(Ship ship) {
        this.ship = ship;
    }

    public Ship getShip() { return ship; }

    public void leaveDock() {
        ship = null;
    }

    @Override
    public String toString() {
        String string = "Dock: " + super.toString();
        if (ship != null) {
            string += "\nShip: ";
            if (ship != null) string += ship;
            else string += "none";
        } else string += "\n";
        return string;
    }
}
