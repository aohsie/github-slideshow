/*
 * File: Ship.java
 * Author: Adam Ohsie
 * Date: October 14, 2018
 * Purpose: The purpose of this class is to set the
 * draft, length, weight, and width of each ship
 *
 */

import java.util.*;

public class Ship extends Thing {
    private ArrayList<Job> jobs = new ArrayList<>();
    private PortTime arrivalTime, dockTime;
    private double draft, length, weight, width;
    private boolean shipIsReady = false;
    private Dock dock = null;

    // scans for draft, length, weight and width
    public Ship(Scanner scanner) {
        super(scanner);
        if (scanner.hasNextDouble()) draft = scanner.nextDouble();
        if (scanner.hasNextDouble()) length = scanner.nextDouble();
        if (scanner.hasNextDouble()) weight = scanner.nextDouble();
        if (scanner.hasNextDouble()) width = scanner.nextDouble();
    }

    public ArrayList<Job> getJobs() { return jobs; }

    public double getDraft() {
        return draft;
    }

    public double getLength() {
        return length;
    }

    public double getWeight() {
        return weight;
    }

    public double getWidth() {
        return width;
    }

    public boolean isShipReady() { return shipIsReady; }

    public void setShipIsReady(Boolean bool) {
        shipIsReady = bool;
    }

    public void setDock(Dock dock) {
        this.dock = dock;
    }

    public Dock getDock() {
        return dock;
    }

    public void dockShip(Ship ship) {
        dock.dockShip(ship);
    }

    @Override
    public String toString() {
        String string = super.toString() + "\nJobs: ";
        if (!jobs.isEmpty()) {
            for (Job job : jobs)
                string += job + "           ";
        } else string += "none" + "\n";
        return string;
    }
}
