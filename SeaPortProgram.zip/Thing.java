/*
 * File: Thing.java
 * Author: Adam Ohsie
 * Date: October 14, 2018
 * Purpose: The purpose of this class is to
 * be the parent to most other classes, and
 * set the name, index, and parent. It also
 * provides the Comparable interface to
 * sort the arraylists by name.
 */

import java.util.*;

public class Thing implements Comparable <Thing> {
    private String name;
    private int index;
    private int parent;

    public Thing() {
        name = "";
        index = 0;
        parent = 0;
    }

    // scans for the name, index, and parent
    public Thing(Scanner scanner) {
        if (scanner.hasNext()) name = scanner.next();
        if (scanner.hasNextInt()) index = scanner.nextInt();
        if (scanner.hasNextInt()) parent = scanner.nextInt();
    }

    public String getName() { return name; }

    public int getIndex() { return index; }

    public int getParent() {
        return parent;
    }

    // used to sort arraylists by name
    @Override
    public int compareTo(Thing thing) {
        return this.name.compareTo(thing.name);
    }

    @Override
    public String toString() {
        return name + " " + index;
    }
}