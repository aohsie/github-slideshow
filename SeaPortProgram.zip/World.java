/*
 * File: World.java
 * Author: Adam Ohsie
 * Date: October 14, 2018
 * Purpose: The purpose of this class is to read in from a scanner
 * and parse the file and create all the port, dock, ship, and person
 * objects, and add them to the correct arrayList, as well as to the
 * correct hashmap so it could be looked up and searched. It also has
 * the methods to sort each arraylist.
 */

import javax.sound.sampled.Port;
import javax.swing.*;
import java.util.*;

public class World extends Thing {
    // arraylist for seaports
    private ArrayList<SeaPort> ports = new ArrayList<>();
    private ArrayList<Dock> allDocks = new ArrayList<>();
    private ArrayList<Ship> allShips = new ArrayList<>();
    private ArrayList<Person> allPersons = new ArrayList<>();
    private ArrayList<Job> allJobs = new ArrayList<>();
    // hashmaps for the seaports
    private static HashMap<Integer, SeaPort> portIndexHashMap = new HashMap<>();
    private static HashMap<String, ArrayList<SeaPort>> portNameHashMap = new HashMap<>();
    // hashmaps for the docks
    private static HashMap<Integer, Dock> dockIndexHashMap = new HashMap<>();
    private static HashMap<String, ArrayList<Dock>> dockNameHashMap = new HashMap<>();
    // hashmaps for the ships
    private static HashMap<Integer, Ship> shipIndexHashMap = new HashMap<>();
    private static HashMap<String, ArrayList<Ship>> shipNameHashMap = new HashMap<>();
    // hashmaps for the persons
    private static HashMap<Integer, Person> personIndexHashMap = new HashMap<>();
    private static HashMap<String, ArrayList<Person>> personNameHashMap = new HashMap<>();
    private static HashMap<String, ArrayList<Person>> personSkillHashMap = new HashMap<>();
    // hashmaps an arraylist for the jobs
    private static HashMap<Integer, Job> jobIndexHashMap = new HashMap<>();
    private static HashMap<String, ArrayList<Job>> jobNameHashMap = new HashMap<>();
    private static HashMap<String, ArrayList<Job>> jobSkillHashMap = new HashMap<>();
    private PortTime time = new PortTime();

    // method that reads in each line of the scanner and creates the
    // appropriate object based on the first key word on each line
    // and adds it to the appropriate arraylist and hashmap
    public void process(Scanner scanner) {
        SeaPort port;
        Dock dock;
        PassengerShip pship;
        CargoShip cship;
        Person person;
        Job job;
        while (scanner.hasNext()) {
            if (scanner.hasNext("//")) {
                scanner.nextLine();
            } else if (scanner.hasNext("port")) {
                scanner.next();
                port = new SeaPort(scanner);
                ports.add(port);
                portIndexHashMap.put(port.getIndex(), port);
                if (!portNameHashMap.containsKey(port.getName())) {
                    ArrayList<SeaPort> portNameArrayList = new ArrayList<>();
                    portNameArrayList.add(port);
                    portNameHashMap.put(port.getName(), portNameArrayList);
                } else portNameHashMap.get(port.getName()).add(port);
            } else if (scanner.hasNext("dock")) {
                scanner.next();
                dock = new Dock(scanner);
                allDocks.add(dock);
                dockIndexHashMap.put(dock.getIndex(), dock);
                if (!dockNameHashMap.containsKey(dock.getName())) {
                    ArrayList<Dock> dockNameArrayList = new ArrayList<>();
                    dockNameArrayList.add(dock);
                    dockNameHashMap.put(dock.getName(), dockNameArrayList);
                } else dockNameHashMap.get(dock.getName()).add(dock);
            } else if (scanner.hasNext("pship")) {
                scanner.next();
                pship = new PassengerShip(scanner);
                allShips.add(pship);
                shipIndexHashMap.put(pship.getIndex(), pship);
                if (!shipNameHashMap.containsKey(pship.getName())) {
                    ArrayList<Ship> shipNameArrayList = new ArrayList<>();
                    shipNameArrayList.add(pship);
                    shipNameHashMap.put(pship.getName(), shipNameArrayList);
                } else shipNameHashMap.get(pship.getName()).add(pship);
            } else if (scanner.hasNext("cship")) {
                scanner.next();
                cship = new CargoShip(scanner);
                allShips.add(cship);
                shipIndexHashMap.put(cship.getIndex(), cship);
                if (!shipNameHashMap.containsKey(cship.getName())) {
                    ArrayList<Ship> shipNameArrayList = new ArrayList<>();
                    shipNameArrayList.add(cship);
                    shipNameHashMap.put(cship.getName(), shipNameArrayList);
                } else shipNameHashMap.get(cship.getName()).add(cship);
            } else if (scanner.hasNext("person")) {
                scanner.next();
                person = new Person(scanner);
                allPersons.add(person);
                personIndexHashMap.put(person.getIndex(), person);
                if (!personNameHashMap.containsKey(person.getName())) {
                    ArrayList<Person> personNameArrayList = new ArrayList<>();
                    personNameArrayList.add(person);
                    personNameHashMap.put(person.getName(), personNameArrayList);
                } else personNameHashMap.get(person.getName()).add(person);
                if (!personSkillHashMap.containsKey(person.getSkill())) {
                    ArrayList<Person> personSkillArrayList = new ArrayList<>();
                    personSkillArrayList.add(person);
                    personSkillHashMap.put(person.getSkill(), personSkillArrayList);
                } else personSkillHashMap.get(person.getSkill()).add(person);
            } else if (scanner.hasNext("job")) {
                scanner.next();
                job = new Job(scanner);
                allJobs.add(job);
                jobIndexHashMap.put(job.getIndex(), job);
                if (!jobNameHashMap.containsKey(job.getName())) {
                    ArrayList<Job> jobNameArrayList = new ArrayList<>();
                    jobNameArrayList.add(job);
                    jobNameHashMap.put(job.getName(), jobNameArrayList);
                } else jobNameHashMap.get(job.getName()).add(job);
                for (String skill : job.getRequirements()) {
                    if (!jobSkillHashMap.containsKey(skill)) {
                        ArrayList<Job> jobSkillArrayList = new ArrayList<>();
                        jobSkillArrayList.add(job);
                        jobSkillHashMap.put(skill, jobSkillArrayList);
                    } else jobSkillHashMap.get(skill).add(job);
                }

            }
        }
        assignPersons();
        assignJobs();
        assignShips();
        assignDocks();
    }

    // method that creates an arraylist of all
    // the ports with the matching name
    public ArrayList<SeaPort> getSeaPortByName(String s) {
        if (!portNameHashMap.isEmpty())
            return portNameHashMap.get(s);
        else return null;
    }

    // method to get the port with
    // the matching index
    public SeaPort getSeaPortByIndex(int x) {
        if (!portIndexHashMap.isEmpty())
            return portIndexHashMap.get(x);
        else return null;
    }

    // method that creates an arraylist of all
    // the docks with the matching name
    public ArrayList<Dock> getDockByName(String s) {
        if (!dockNameHashMap.isEmpty())
            return dockNameHashMap.get(s);
        else return null;
    }

    // method to get the dock with
    // the matching index
    public Dock getDockByIndex(int x) {
        if (!dockIndexHashMap.isEmpty())
            return dockIndexHashMap.get(x);
        else return null;
    }

    // method that creates an arraylist of all
    // the ships with the matching name
    public ArrayList<Ship> getShipByName(String s) {
        if (!shipNameHashMap.isEmpty())
            return shipNameHashMap.get(s);
        else return null;
    }

    // method to get the ship with
    // the matching index
    public Ship getShipByIndex(int x) {
        if (!shipIndexHashMap.isEmpty())
            return shipIndexHashMap.get(x);
        else return null;
    }

    // method that creates an arraylist of all
    // the people with the matching name
    public ArrayList<Person> getPersonByName(String s) {
        if (!personNameHashMap.isEmpty())
            return personNameHashMap.get(s);
        else return null;
    }

    // method to get the person with
    // the matching index
    public Person getPersonByIndex(int x) {
        if (!personIndexHashMap.isEmpty())
            return personIndexHashMap.get(x);
        else return null;
    }

    // method that creates an arraylist of all
    // the people with the matching skill
    public ArrayList<Person> getPersonBySkill(String s) {
        if (!personSkillHashMap.isEmpty())
            return personSkillHashMap.get(s);
        else return null;
    }

    // method that creates an arraylist of all
    // the jobs with the matching name
    public ArrayList<Job> getJobByName(String s) {
        if (!jobNameHashMap.isEmpty())
            return jobNameHashMap.get(s);
        else return null;
    }

    // method to get the job with
    // the matching index
    public Job getJobByIndex(int x) {
        if (!jobIndexHashMap.isEmpty())
            return jobIndexHashMap.get(x);
        else return null;
    }

    // method that creates an arraylist of all
    // the jobs with the matching skill
    public ArrayList<Job> getJobBySkill(String s) {
        if (!jobSkillHashMap.isEmpty())
            return jobSkillHashMap.get(s);
        else return null;
    }

    // assigns a dock to appropriate port
    public void assignDocks() {
        SeaPort port;
        for (Dock dock : allDocks) {
            port = getSeaPortByIndex(dock.getParent());
            port.getDocks().add(dock);
            if (dock.getShip() == null)
                port.getDockStack().push(dock);
        }
    }

    // assigns a ship to appropriate dock or port
    public void assignShips() {
        for (Ship ship : allShips) {
            Dock dock = getDockByIndex(ship.getParent());
            if (!ship.getJobs().isEmpty()) {
                if (dock != null) {
                    getSeaPortByIndex(dock.getParent()).getShips().add(ship);
                    getSeaPortByIndex(dock.getParent()).getQue().add(ship);
                } else {
                    getSeaPortByIndex(ship.getParent()).getShips().add(ship);
                    getSeaPortByIndex(ship.getParent()).getQue().add(ship);

                }
            } else {
                if (dock != null)
                    getSeaPortByIndex(dock.getParent()).getShips().add(ship);
                else getSeaPortByIndex(ship.getParent()).getShips().add(ship);
            }
        }
    }

    // assigns a person to appropriate port and resource pool
    public void assignPersons() {
        SeaPort port;
        for (Person person : allPersons) {
            port = getSeaPortByIndex(person.getParent());
            port.getPersons().add(person);
            if (!port.getPersonSkillArrayListHashMap().containsKey(person.getSkill())) {
                // creates an arraylist for each skill, adding each person with
                // that skill in order to create the resource pools
                ArrayList<Person> personSkillArrayList = new ArrayList<>();
                personSkillArrayList.add(person);
                // puts the pool in a hashmap
                port.getPersonSkillArrayListHashMap().put(person.getSkill(), personSkillArrayList);
                // sets the counter for the pool to one
                port.getSkillCounterHashMap().put(person.getSkill(), 1);
                port.getSkillArrayList().add(person.getSkill());
            } else {
                port.getPersonSkillArrayListHashMap().get(person.getSkill()).add(person);
                // raises the counter for the pool
                port.getSkillCounterHashMap().replace
                        (person.getSkill(), port.getPersonSkillArrayListHashMap().get(person.getSkill()).size());
            }
        }
    }

    // assigns jobs to appropriate ship
    public void assignJobs() {
        for (Job job : allJobs)
            getShipByIndex(job.getParent()).getJobs().add(job);
    }

    // sorts the seaport arraylist
    public void sortSeaPorts() {
        Collections.sort(ports);
    }

    // sorts the dock arraylist
    public void sortDocks() {
        for (SeaPort port : ports)
            Collections.sort(port.getDocks());
    }

    // sorts the ships in que arraylist
    public void sortShipsInQue() {
        for (SeaPort port : ports)
            Collections.sort(port.getQue());
    }

    // sorts the ship arraylist
    public void sortShips() {
        for (SeaPort port : ports)
            Collections.sort(port.getShips());
    }

    // sorts the people arraylist
    public void sortPeople() {
        for (SeaPort port : ports)
            Collections.sort(port.getPersons());
    }

    // sorts the job arraylist
    public void sortJobs() {
        for (SeaPort port : ports)
            for (Ship ship : port.getShips())
                Collections.sort(ship.getJobs());
    }

    // sorts the ships in que by draft
    public void sortQueByDraft() {
        for (SeaPort port : ports)
            Collections.sort(port.getQue(), new Comparator<Ship>() {
                @Override
                public int compare(Ship o1, Ship o2) {
                    return Double.compare(o1.getDraft(), o2.getDraft());
                }
            });
    }

    // sorts by length
    public void sortQueByLength() {
        for (SeaPort port : ports)
            Collections.sort(port.getQue(), new Comparator<Ship>() {
                @Override
                public int compare(Ship o1, Ship o2) {
                    return Double.compare(o1.getLength(), o2.getLength());
                }
            });
    }

    // sorts by weight
    public void sortQueByWeight() {
        for (SeaPort port : ports)
            Collections.sort(port.getQue(), new Comparator<Ship>() {
                @Override
                public int compare(Ship o1, Ship o2) {
                    return Double.compare(o1.getWeight(), o2.getWeight());
                }
            });
    }

    // sorts by width
    public void sortQueByWidth() {
        for (SeaPort port : ports)
            Collections.sort(port.getQue(), new Comparator<Ship>() {
                @Override
                public int compare(Ship o1, Ship o2) {
                    return Double.compare(o1.getWidth(), o2.getWidth());
                }
            });
    }

    public HashMap<Integer, SeaPort> getPortIndexHashMap() {
        return portIndexHashMap;
    }

    public HashMap<String, ArrayList<SeaPort>> getPortNameHashMap() {
        return portNameHashMap;
    }

    public HashMap<Integer, Dock> getDockIndexHashMap() {
        return dockIndexHashMap;
    }

    public HashMap<String, ArrayList<Dock>> getDockNameHashMap() {
        return dockNameHashMap;
    }

    public HashMap<String, ArrayList<Ship>> getShipNameHashMap() {
        return shipNameHashMap;
    }

    public HashMap<String, ArrayList<Person>> getPersonNameHashMap() {
        return personNameHashMap;
    }

    public HashMap<String, ArrayList<Person>> getPersonSkillHashMap() {
        return personSkillHashMap;
    }

    public HashMap<String, ArrayList<Job>> getJobNameHashMap() {
        return jobNameHashMap;
    }

    public HashMap<String, ArrayList<Job>> getJobSkillHashMap() {
        return jobSkillHashMap;
    }

    public ArrayList<SeaPort> getPorts() {
        return ports;
    }

    public ArrayList<Job> getAllJobs() {
        return allJobs;
    }

    @Override
    public String toString() {
        String string = ">>>>> The World: \n\n";
        for (SeaPort port : ports)
            string += port;
        return string;
    }
}
